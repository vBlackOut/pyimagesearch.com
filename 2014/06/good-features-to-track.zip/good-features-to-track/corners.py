# USAGE
# python corners.py --image images/map.png --corners 50

# import the necessary packages
import numpy as np
import argparse
import cv2

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", required = True, help = "Path to the image")
ap.add_argument("-c", "--corners", type = int, default = 20,
	help = "# of corners to detect")
args = vars(ap.parse_args())

# load the image and convert it to grayscale
image = cv2.imread(args["image"])
orig = image.copy()
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# detect corners in the image
corners = cv2.goodFeaturesToTrack(gray, args["corners"], 0.01, 10)

# loop over the corners
for c in corners:
	# convert the corners to integers and grab the (x, y)
	# coordinates, then draw the corner
	(x, y) = np.int32(c.ravel())
	cv2.circle(image, (x, y), 5, (0, 0, 255), 2)

# show the image
cv2.imshow("Images", np.hstack([orig, image]))
cv2.waitKey(0)